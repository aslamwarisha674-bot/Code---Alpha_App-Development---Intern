import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(const QuotifyUltraApp());
}

class QuotifyUltraApp extends StatelessWidget {
  const QuotifyUltraApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quotify Enterprise',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFF0F4F8), // SOFT SOLID BACKGROUND
        primaryColor: const Color(0xFF1A1A1A),
      ),
      home: const SplashActivity(),
    );
  }
}

class Quote {
  final String text;
  final String author;
  final String category; 
  final List<Color> cardGradient; 
  final TextStyle textStyle; 

  Quote({
    required this.text, 
    required this.author, 
    required this.category,
    required this.cardGradient,
    required this.textStyle,
  });
}

// ==========================================
// SCREEN 1: SPLASH INFRASTRUCTURE
// ==========================================
class SplashActivity extends StatefulWidget {
  const SplashActivity({Key? key}) : super(key: key);

  @override
  State<SplashActivity> createState() => _SplashActivityState();
}

class _SplashActivityState extends State<SplashActivity> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const MainActivity()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A1A), 
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.dashboard_customize_outlined, size: 60, color: Color(0xFFD4E157)), 
            SizedBox(height: 24),
            Text(
              "QUOTIFY ENTERPRISE",
              style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold, letterSpacing: 4.0),
            ),
            SizedBox(height: 8),
            Text(
              "Initializing Adaptive UI Engine...",
              style: TextStyle(color: Color(0xFF888888), fontSize: 11, letterSpacing: 1.0),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// SCREEN 2: MAIN ULTRA WORKBENCH
// ==========================================
class MainActivity extends StatefulWidget {
  const MainActivity({Key? key}) : super(key: key);

  @override
  State<MainActivity> createState() => _MainActivityState();
}

class _MainActivityState extends State<MainActivity> {
  final List<Quote> _quotesRepository = [
    Quote(
      text: "The only way to do great work is to love what you do.", 
      author: "Steve Jobs",
      category: "#LEADERSHIP",
      cardGradient: [const Color(0xFFE0F7FA), const Color(0xFFB2EBF2)], 
      textStyle: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: Color(0xFF0F172A), height: 1.4, fontFamily: 'serif'),
    ),
    Quote(
      text: "Make it simple, but significant.", 
      author: "Don Draper",
      category: "#MINIMALISM",
      cardGradient: [const Color(0xFFF3E5F5), const Color(0xFFE1BEE7)], 
      textStyle: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: Color(0xFF2A2A2A), letterSpacing: 0.2, height: 1.4),
    ),
    Quote(
      text: "Strive not to be a success, but rather to be of value.", 
      author: "Albert Einstein",
      category: "#VALUE",
      cardGradient: [const Color(0xFFE8F5E9), const Color(0xFFC8E6C9)], 
      textStyle: const TextStyle(fontSize: 20, fontStyle: FontStyle.italic, color: Color(0xFF1B5E20), height: 1.5),
    ),
    Quote(
      text: "Simplicity is the ultimate sophistication.", 
      author: "Leonardo da Vinci",
      category: "#DESIGN",
      cardGradient: [const Color(0xFFFFF3E0), const Color(0xFFFFE0B2)], 
      textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600, color: Color(0xFF4E342E), height: 1.4),
    ),
    Quote(
      text: "Talk is cheap. Show me the code.", 
      author: "Linus Torvalds",
      category: "#INNOVATION",
      cardGradient: [const Color(0xFFECEFF1), const Color(0xFFCFD8DC)], 
      textStyle: const TextStyle(fontSize: 21, fontFamily: 'monospace', fontWeight: FontWeight.bold, color: Color(0xFF1E88E5), height: 1.4),
    ),
  ];

  late Quote _currentQuote;
  int _lastRandomIndex = -1;
  final List<Quote> _historyLog = []; 
  final Random _random = Random();

  @override
  void initState() {
    super.initState();
    _generateSeamlessQuote();
  }

  void _generateSeamlessQuote() {
    if (_quotesRepository.isEmpty) return;
    int index = _random.nextInt(_quotesRepository.length);

    if (_quotesRepository.length > 1) {
      while (index == _lastRandomIndex) {
        index = _random.nextInt(_quotesRepository.length);
      }
    }

    setState(() {
      _lastRandomIndex = index;
      _currentQuote = _quotesRepository[index];
      _historyLog.insert(0, _currentQuote);
    });
  }

  // Fallback direct dialog presentation since sharing plugin requires platform configuration
  void _showShareDialog(Quote quote) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("PRO SYSTEM SHARE SHEET", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
        content: Text("${quote.text}\n\n— ${quote.author}\n${quote.category}"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Copy to Clipboard Layout", style: TextStyle(color: Color(0xFF0F172A))),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("QUOTIFY ADAPTIVE", style: TextStyle(color: Color(0xFF1A1A1A), fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 2.0)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.analytics_outlined, color: Color(0xFF475569)),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const AboutActivity())),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.history_toggle_off_rounded, color: Color(0xFF475569)),
            onPressed: () {
               showModalBottomSheet(
                context: context,
                backgroundColor: Colors.white,
                shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
                builder: (context) {
                  return Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("VALIDATION HISTORY", style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF64748B), letterSpacing: 1.5)),
                        const SizedBox(height: 16),
                        Expanded(
                          child: ListView.builder(
                            itemCount: _historyLog.length,
                            itemBuilder: (context, index) => Container(
                              margin: const EdgeInsets.only(bottom: 10),
                              decoration: BoxDecoration(color: const Color(0xFFF1F5F9), borderRadius: BorderRadius.circular(10)),
                              child: ListTile(
                                title: Text(_historyLog[index].text, style: const TextStyle(fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis), 
                                subtitle: Text(_historyLog[index].author, style: const TextStyle(fontSize: 11)),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            const Spacer(),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              transitionBuilder: (child, animation) => FadeTransition(opacity: animation, child: child),
              child: GestureDetector(
                key: ValueKey(_lastRandomIndex), 
                onLongPress: () => _showShareDialog(_currentQuote), 
                child: Container(
                  padding: const EdgeInsets.all(32.0),
                  height: 350,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: _currentQuote.cardGradient, begin: Alignment.topLeft, end: Alignment.bottomRight,),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.01), blurRadius: 20, offset: const Offset(0, 10))],
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(Icons.layers_outlined, size: 20, color: _currentQuote.cardGradient.last.withOpacity(0.6)), // ERROR FIX: Const removed here
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(color: Colors.black.withOpacity(0.04), borderRadius: BorderRadius.circular(20)),
                            child: Text(_currentQuote.category, style: TextStyle(color: _currentQuote.textStyle.color!.withOpacity(0.7), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 32),
                      Expanded(child: Center(child: Text(_currentQuote.text, textAlign: TextAlign.center, style: _currentQuote.textStyle,),),),
                      const SizedBox(height: 16),
                      Text("— ${_currentQuote.author}", style: TextStyle(color: _currentQuote.textStyle.color!.withOpacity(0.6), fontSize: 13, fontWeight: FontWeight.w600, letterSpacing: 0.2,),),
                    ],
                  ),
                ),
              ),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: _generateSeamlessQuote,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1A1A1A),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 21),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
              child: const Center(child: Text("Synchronize Next Asset Layout", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 1.0))),
            ),
            const SizedBox(height: 12),
            const Text("Long Press Card to View Asset Data", style: TextStyle(color: Color(0xFF888888), fontSize: 12, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// SCREEN 3: DEVELOPER ARCHITECTURE SUITE
// ==========================================
class AboutActivity extends StatelessWidget {
  const AboutActivity({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Color(0xFF0F172A), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("ENTERPRISE INFRASTRUCTURE", style: TextStyle(color: Color(0xFF64748B), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 2.0)),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.01), blurRadius: 15, offset: const Offset(0, 5))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text("Quotify Engine Suite", style: TextStyle(color: Color(0xFF0F172A), fontSize: 22, fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text("v2.0.0 (Dynamic Theme Production Stack)", style: TextStyle(color: Color(0xFF38BDF8), fontSize: 12, fontWeight: FontWeight.bold)),
                  Padding(padding: EdgeInsets.symmetric(vertical: 16.0), child: Divider(color: Color(0xFFE2E8F0))),
                  Text("Architecture Highlights", style: TextStyle(color: Color(0xFF475569), fontSize: 13, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text(
                    "Engineered with a synchronized memory history layout and real-time aesthetic mutations. Completely modular, single-file composition ideal for rapid screening validations.",
                    style: TextStyle(color: Color(0xFF334155), fontSize: 14, height: 1.5),
                  ),
                ],
              ),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F172A),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 18),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                minimumSize: const Size(double.infinity, 0),
                elevation: 0,
              ),
              child: const Text("Return to Workspace", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
            )
          ],
        ),
      ),
    );
  }
}