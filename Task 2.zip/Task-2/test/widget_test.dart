import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Clipboard operations ke liye lazmi hai

void main() {
  runApp(const QuotifyUltraApp());
}

class QuotifyUltraApp extends StatelessWidget {
  const QuotifyUltraApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quotify Enterprise Pro',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFF1F5F9), // Smooth Clean Soft Background
        primaryColor: const Color(0xFF0F172A),
      ),
      home: const SplashActivity(),
    );
  }
}

class Quote {
  final String text;
  final String author;
  final String category; 
  final List<Color> cardGradient; 

  Quote({
    required this.text, 
    required this.author, 
    required this.category,
    required this.cardGradient,
  });
}

// ==========================================
// SCREEN 1: SPLASH INFRASTRUCTURE
// ==========================================
class SplashActivity extends StatefulWidget {
  const SplashActivity({Key? key}) : super(key: key);

  @override
  State<SplashActivity> createState() => _SplashActivityState();
}

class _SplashActivityState extends State<SplashActivity> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const MainActivity()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A), 
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.layers_rounded, size: 64, color: Color(0xFF38BDF8)), 
            SizedBox(height: 24),
            Text(
              "QUOTIFY PRO ENGINE",
              style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 4.0),
            ),
            SizedBox(height: 8),
            Text(
              "Deploying 3D Vector Workspace...",
              style: TextStyle(color: Color(0xFF64748B), fontSize: 11, letterSpacing: 1.0),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// SCREEN 2: MAIN ADVANCED WORKBENCH (3D REVOLVE)
// ==========================================
class MainActivity extends StatefulWidget {
  const MainActivity({Key? key}) : super(key: key);

  @override
  State<MainActivity> createState() => _MainActivityState();
}

class _MainActivityState extends State<MainActivity> with SingleTickerProviderStateMixin {
  final List<Quote> _quotesRepository = [
    Quote(
      text: "The only way to do great work is to love what you do.", 
      author: "Steve Jobs",
      category: "#LEADERSHIP",
      cardGradient: [const Color(0xFFE0F7FA), const Color(0xFFB2EBF2)], // Soft Cyan Mint
    ),
    Quote(
      text: "Make it simple, but significant.", 
      author: "Don Draper",
      category: "#MINIMALISM",
      cardGradient: [const Color(0xFFF3E5F5), const Color(0xFFE1BEE7)], // Soft Pastel Lavender
    ),
    Quote(
      text: "Strive not to be a success, but rather to be of value.", 
      author: "Albert Einstein",
      category: "#VALUE",
      cardGradient: [const Color(0xFFE8F5E9), const Color(0xFFC8E6C9)], // Soft Pale Green
    ),
    Quote(
      text: "Simplicity is the ultimate sophistication.", 
      author: "Leonardo da Vinci",
      category: "#DESIGN",
      cardGradient: [const Color(0xFFFFF3E0), const Color(0xFFFFE0B2)], // Soft Light Peach
    ),
    Quote(
      text: "Talk is cheap. Show me the code.", 
      author: "Linus Torvalds",
      category: "#INNOVATION",
      cardGradient: [const Color(0xFFECEFF1), const Color(0xFFCFD8DC)], // Soft Silver Blue
    ),
  ];

  late Quote _currentQuote;
  int _lastRandomIndex = -1;
  final List<Quote> _historyLog = []; 
  final List<Quote> _favoritesLog = []; // Feature: Favorites Storage Panel
  final Random _random = Random();

  // Animation controllers for the 3D Revolution
  late AnimationController _animationController;
  late Animation<double> _revolveAnimation;

  @override
  void initState() {
    super.initState();
    _currentQuote = _quotesRepository[0];
    _historyLog.add(_currentQuote);

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600), // Sleek rotation velocity
    );

    _revolveAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  // Triggering the 3D Revolve along with data synchronization
  void _triggerRevolveAndSync() {
    if (_animationController.isAnimating) return;

    _animationController.forward().then((_) {
      int index = _random.nextInt(_quotesRepository.length);
      if (_quotesRepository.length > 1) {
        while (index == _lastRandomIndex) {
          index = _random.nextInt(_quotesRepository.length);
        }
      }

      setState(() {
        _lastRandomIndex = index;
        _currentQuote = _quotesRepository[index];
        _historyLog.insert(0, _currentQuote);
      });

      _animationController.reverse();
    });
  }

  void _copyToClipboard(Quote quote) {
    Clipboard.setData(ClipboardData(text: "${quote.text} — ${quote.author}"));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Asset payload copied to system clipboard layout."),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF0F172A),
      ),
    );
  }

  void _toggleFavorite(Quote quote) {
    setState(() {
      if (_favoritesLog.contains(quote)) {
        _favoritesLog.remove(quote);
      } else {
        _favoritesLog.add(quote);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("QUOTIFY CORE V3", style: TextStyle(color: Color(0xFF0F172A), fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 2.0)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.history_toggle_off_rounded, color: Color(0xFF475569)),
          onPressed: () => _openModalLog("VALIDATION TRACK LOG", _historyLog),
        ),
        actions: [
          IconButton(
            icon: Icon(
              _favoritesLog.contains(_currentQuote) ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
              color: _favoritesLog.contains(_currentQuote) ? const Color(0xFF0F172A) : const Color(0xFF475569),
            ),
            onPressed: () => _toggleFavorite(_currentQuote),
          ),
          IconButton(
            icon: const Icon(Icons.folder_special_outlined, color: Color(0xFF475569)),
            onPressed: () => _openModalLog("FAVORITES ARCHIVE", _favoritesLog),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            const Spacer(),
            // 3D Revolve Transform Mechanics Engine
            AnimatedBuilder(
              animation: _revolveAnimation,
              builder: (context, child) {
                final transformValue = _revolveAnimation.value * pi;
                return Transform(
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.001) // Depth perception factor
                    ..rotateY(transformValue), // Revolving on Y-Axis
                  alignment: Alignment.center,
                  child: transformValue >= pi / 2
                      ? const SizedBox(height: 360) // Buffer state during mid-flip
                      : GestureDetector(
                          onLongPress: () => _copyToClipboard(_currentQuote),
                          child: Container(
                            padding: const EdgeInsets.all(32.0),
                            height: 360,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: _currentQuote.cardGradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
                              borderRadius: BorderRadius.circular(24),
                              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 30, offset: const Offset(0, 15))],
                            ),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Icon(Icons.blur_on_rounded, size: 22, color: Color(0xFF475569)),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                                      decoration: BoxDecoration(color: Colors.black.withOpacity(0.04), borderRadius: BorderRadius.circular(20)),
                                      child: Text(_currentQuote.category, style: const TextStyle(color: Color(0xFF475569), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                                    ),
                                  ],
                                ),
                                const Spacer(),
                                // Requirement: All quotes hardcoded to crisp elegant italic styles
                                Text(
                                  _currentQuote.text,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w600, fontStyle: FontStyle.italic, color: Color(0xFF1E293B), height: 1.5, fontFamily: 'serif'),
                                ),
                                const Spacer(),
                                Text("— ${_currentQuote.author}", style: const TextStyle(color: Color(0xFF64748B), fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                              ],
                            ),
                          ),
                        ),
                );
              },
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: _triggerRevolveAndSync,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F172A),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 22),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 0,
              ),
              child: const Center(child: Text("Revolve Asset Environment", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 1.5))),
            ),
            const SizedBox(height: 14),
            const Text("Long Press Card to Copy Layout Data", style: TextStyle(color: Color(0xFF64748B), fontSize: 12, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }

  void _openModalLog(String title, List<Quote> sourceList) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF64748B), letterSpacing: 1.5)),
              const SizedBox(height: 16),
              Expanded(
                child: sourceList.isEmpty
                    ? const Center(child: Text("No records registered in this infrastructure matrix."))
                    : ListView.builder(
                        itemCount: sourceList.length,
                        itemBuilder: (context, index) => Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE2E8F0))),
                          child: ListTile(
                            title: Text(sourceList[index].text, style: const TextStyle(fontSize: 13, fontStyle: FontStyle.italic), maxLines: 1, overflow: TextOverflow.ellipsis),
                            subtitle: Text(sourceList[index].author, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}