package com.example.professional_quote_genrator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
